function getBotResponse(input) {
    // Rock paper scissors
    if (input == "rock") {
        return "I choose paper! I win!";
    } else if (input == "paper") {
        return "I choose scissors! I win!";
    } else if (input == "scissors") {
        return "I choose rock! I win!";
    }

    // Simple responses
    if (input == "Hi") {
        return "Hi there! How can I assist you today?";
    } else if (input == "goodbye") {
        return "Keep in touch! Have a great day!";
    } else if (input.includes("weather")) {
        return "I'm sorry, I can't provide weather information right now. Is there something else you'd like to know?";
    } else if (input.includes("joke")) {
        let jokes = [
            "Why did the tomato turn red? Because it saw the salad dressing!",
            "Why don't scientists trust atoms? Because they make up everything.",
            "Why did the coffee file a police report? It got mugged.",
            "Why did the scarecrow win an award? Because he was outstanding in his field!",
            "What do you get when you cross a snowman and a shark? Frostbite."
        ];
        let randomJoke = jokes[Math.floor(Math.random() * jokes.length)];
        return randomJoke;
    } else {
        let responses = [
            "I'm not sure what you're asking. Could you try rephrasing the question?",
            "I'm sorry, I didn't understand. Can you please provide more information?",
            "I'm not programmed to respond to that question. Is there something else you'd like to know?",
            "Try to ask something else!"
        ];
        let randomResponse = responses[Math.floor(Math.random() * responses.length)];
        return randomResponse;
    }



}
